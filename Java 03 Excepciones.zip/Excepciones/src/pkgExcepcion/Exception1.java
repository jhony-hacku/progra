/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkgExcepcion;

/**
 *
 * @author user
 */
public class Exception1 {
    public static void main(String args[]){
        int arreglo[] =  new int [10];

        for (int i=0 ; i<=arreglo.length ;i++ )  {
            System.out.println(arreglo[i]);
        }
        System.out.println("Fin del programa");

    }
    
}
