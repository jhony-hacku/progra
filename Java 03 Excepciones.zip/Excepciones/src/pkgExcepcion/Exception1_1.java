/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkgExcepcion;

/**
 *
 * @author user
 */
public class Exception1_1 {
    public static void main(String args[]){
        int arreglo[] =  new int [10];
           
            for (int i=0 ; i<=13 ;i++ )  {
                try{ 
                        arreglo[i]=i*i;
                        System.out.println(arreglo[i]);
                }

                catch (ArrayIndexOutOfBoundsException ex){
                   System.out.println("Se presenta error ["+ex.getMessage()+"]");
                   ex.printStackTrace();
                   i=14;
                }
                
            }
        
        System.out.println("Fin del programa");

    }
    
}
