/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package agenda;

/**
 *
 * @author Orlando
 */
import java.util.Scanner;

public class Persona {

    private String nombre;
    private String telefono;
    private String correo;
    private int edad;
    // Constructor
    public Persona(String nombre, String telefono, String correo,int edad) {
        this.nombre = nombre;
        this.telefono = telefono;
        this.correo = correo;
        this.edad=edad;
    }

    // Getters
    public String getNombre() {
        return nombre;
    }

    public String getTelefono() {
        return telefono;
    }

    public String getCorreo() {
        return correo;
    }

    // Método para mostrar la información del contacto
    public void mostrarContacto() {
        System.out.println("Nombre: " + nombre);
        System.out.println("Teléfono: " + telefono);
        System.out.println("Correo: " + correo);
        System.out.println("-------------------------");
    }

    /*public String toString() {
        String info = "Nombre: " + nombre
                + "\nTeléfono: " + telefono
                + "\nCorreo: " + correo
                + "\nEdad: " + edad
                + "\n-------------------------";
        
        return info;
    }
*/
    /**
     * @return the edad
     */
    public int getEdad() {
        return edad;
    }

    /**
     * @param edad the edad to set
     */
    public void setEdad(int edad) {
        this.edad = edad;
    }
}
