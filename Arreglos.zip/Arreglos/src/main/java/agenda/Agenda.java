/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package agenda;

/**
 *
 * @author Orlando
 */
import java.util.Scanner;



public class Agenda {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Persona[] agenda = new Persona[100]; // Arreglo para almacenar hasta 100 contactos
        int indice = 0; // Para llevar el conteo de los registros almacenados

        while (true) {
            System.out.print("Ingrese el nombre del contacto (o 'fin' para terminar): ");
            String nombre = scanner.nextLine();

            // Verificar si el nombre es "fin" para terminar el ciclo
            if (nombre.equalsIgnoreCase("fin")) {
                break;
            }

            System.out.print("Ingrese el teléfono del contacto: ");
            String telefono = scanner.nextLine();

            System.out.print("Ingrese el correo electrónico del contacto: ");
            String correo = scanner.nextLine();
            
           // System.out.print("Ingrese la edad del contacto: ");
           // int edad = scanner.nextInt();

            // Almacenar el nuevo contacto en el arreglo
            agenda[indice] = new Persona(nombre, telefono, correo,0);
            indice++;

            // Verificar que no se exceda el máximo de 100 contactos
            if (indice >= 100) {
                System.out.println("La agenda está llena. No se pueden agregar más contactos.");
                break;
            }
        }

        // Mostrar los contactos almacenados
        System.out.println("\nContactos almacenados en la agenda:");
        for (int i = 0; i < indice; i++) {
            //agenda[i].mostrarContacto();
            String retorno=  agenda[i].toString();
            System.out.println("Informacion:\n"+retorno);
        }
    }
}
