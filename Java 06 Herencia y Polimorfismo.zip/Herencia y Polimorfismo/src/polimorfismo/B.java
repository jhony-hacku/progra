/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package polimorfismo;

/**
 *
 * @author user
 */
public class B extends A {
     public int lb;
     public void dummyB(){
         System.out.println ("Dumy B en B");
     }
}
