/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package polimorfismo;

/**
 *
 * @author user
 */
public class D extends C{
    public int ld;
    public void dummyD(){
        System.out.println ("Dumy D en D");
    }
}
