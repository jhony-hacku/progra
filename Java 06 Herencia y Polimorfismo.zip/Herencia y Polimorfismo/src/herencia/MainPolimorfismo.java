package herencia;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author user
 */
public class MainPolimorfismo {
    public static void main (String args[]){
        Animal animal = new Animal();
        Animal perro =  new Mamifero();
        Animal cocodrilo= new Reptil();
        Reptil caiman = new Reptil();
        /*Esto si se puede
        Animal m = new Mamifero();
        Animal r  = new Reptil();
        r=m;
        */
        
        caiman.setEspecie("Caiman");
        caiman.setNombre("Caimancito");
        caiman.setPeso(520f);
        System.out.println("----------Definicion de Caiman\n"+caiman.toString()+"\n------");
        
        
        cocodrilo.setEspecie("saurópsidos arcosaurios");
        cocodrilo.setNombre("Cocodrilo");
        cocodrilo.setPeso(730f);
        
        if (cocodrilo instanceof Reptil){
            System.out.println("El cocodrilo es creado del Reptil");
            
            ((Reptil)cocodrilo).setHuevos(2);
            ((Reptil) cocodrilo).setHuevos(12);   
            
            System.out.println ("Una mamá cocodrilo coloca maximo "+ ((Reptil) cocodrilo).getHuevos()+" huevos a la vez!!");
            System.out.println ("Info del cocodrilo 1 "+ ((Reptil) cocodrilo).toString());
            System.out.println ("Info del cocodrilo 2 "+ cocodrilo.toString()); //Igual que en la linea anterior
            System.out.println ("Info del cocodrilo 3 "+ cocodrilo.toString1()); //Igual que en la linea anterior
            
            /*
            ((Mamifero) cocodrilo).setLactancia(3);
             System.out.println ("Lactancia del cocodrilo "+ ((Mamifero)cocodrilo).getLactancia());
            */
        }
        if (perro instanceof Ave)
            System.out.println("El perro extiende deL Ave");
        else
            System.out.println("El perro NO extiende del Ave");

        
        /*Si es posible */
        Animal m = new Mamifero();
        m.setEspecie("Felis silvestris catus");
        m.setNombre("Gato");
        m.setPeso(5f);
        Animal r  = new Reptil();
        Animal r2 = new Reptil();
        r=m;
        System.out.println("Letrero de reptil a mamifero:"+r.toString());
        
        r2.setEspecie("saurópsidos arcosaurios2");
        r2.setNombre("Cocodrilo2");
        r2.setPeso(730f);
        ((Mamifero)r2).setLactancia(10);
        System.out.println("Informacion del cocodrilo:\n"+   r2.toString());
        System.out.println("El cocodrilo lacta?:\n"+   ((Mamifero)r2).getLactancia());
     
        Ave2 aguila = new Ave2("Aquila chrysaetos","águila real",2900f);        
        System.out.println("Informacion del Aguila:\n"+   aguila.toString());
    }
    
    
}
