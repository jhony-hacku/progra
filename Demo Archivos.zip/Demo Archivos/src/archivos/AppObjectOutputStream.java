/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package archivos;


import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.OutputStream;


/**
 *
 * @author user
 */
public class AppObjectOutputStream extends ObjectOutputStream {

    public AppObjectOutputStream(OutputStream out) throws IOException{
            super(out);
        
    }
  protected void writeStreamHeader() throws IOException {
    // do not write a header
  }

}
