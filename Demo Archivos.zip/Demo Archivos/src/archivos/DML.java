/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package archivos;

import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;

/**
 *
 * @author user
 */
public class DML {

    private static ObjectInputStream oi = null;
    private static FileInputStream fi = null;
    private static ObjectOutputStream ou = null;
    private static FileOutputStream fo = null;
    private static final String ARCHIVO = "agenda.dat";
    private static final String RUTA = "src"+ File.separator +"archivos"+ File.separator +"datos";

    public static void demo() {

    }

    private static boolean validarCarpeta() {
        boolean rta = true;
        Path path = Paths.get("");
        String directoryName = path.toAbsolutePath().toString();
        File carpeta = new File(directoryName + File.separator + RUTA);
        if (!carpeta.exists()) {
            if (carpeta.mkdirs()) {
                System.out.println("Carpeta creada");
            } else {
                System.out.println("Error al crear carpeta " + carpeta);
                rta = false;
            }
        }
        return rta;
    }

    private static void abrirArchivoR() {

        Path path = Paths.get("");
        String directoryName = path.toAbsolutePath().toString();
        File carpeta = new File(directoryName + File.separator + RUTA);
        File archivoDatos = new File(carpeta.getAbsolutePath() + File.separator + ARCHIVO);
        boolean archivoExiste = false;
        if (archivoDatos.length() > 0 && archivoDatos.exists()) {
            archivoExiste = true;
        }
        try {
            fi = new FileInputStream(carpeta.getAbsolutePath() + File.separator + ARCHIVO);
            oi = new ObjectInputStream(fi);
        } catch (FileNotFoundException ex) {
            oi = null;
            System.out.println("Archivo de Personas no ha sido creado");
        } catch (IOException ex) {
            oi = null;
            ex.printStackTrace();

        }

    }

    private static void abrirArchivoW() {

        Path path = Paths.get("");
        String directoryName = path.toAbsolutePath().toString();
        File carpeta = new File(directoryName + File.separator + RUTA);
        File archivoDatos = new File(carpeta.getAbsolutePath() + File.separator + ARCHIVO);
        boolean archivoExiste = false;
        if (archivoDatos.length() > 0 && archivoDatos.exists()) {
            archivoExiste = true;
        }
        try {
            fo = new FileOutputStream(carpeta.getAbsolutePath() + File.separator + ARCHIVO, true);
            if (!archivoExiste) {
                ou = new ObjectOutputStream(fo);
            } else {
                ou = new AppObjectOutputStream(fo);
            }
        } catch (FileNotFoundException ex) {
            ou = null;
            ex.printStackTrace();
        } catch (IOException ex) {
            ou = null;
            ex.printStackTrace();

        }

    }

    public static boolean add(Persona p, boolean reescribir) {

        boolean rta = true;
        if (validarCarpeta()) {
            abrirArchivoW();
            if (ou != null) {
                try {
                    ou.writeObject(p);
                    if (reescribir == false) {
                        System.out.println("Registro adicionado correctamente.\n");
                    } else {
                        //No muestro ningun mensaje
                    }

                } catch (IOException ex) {
                    rta = false;
                    ex.printStackTrace();
                } finally {
                    if (ou != null) {
                        try {
                            //Cerramos el objeto outputStream y el archivo
                            ou.close();
                            fo.close();
                        } catch (IOException ex) {
                            rta = false;
                            ex.printStackTrace();
                        }
                    }
                }
            }
        } else {
            rta = false;
        }
        return rta;
    }

    public static boolean consultarPersona() {
        System.out.println("====================");
        System.out.println("CONSULTA DE PERSONAS");
        System.out.println("====================");

        boolean rta = true;
        String parametro = null;
        Persona p = null;
        Scanner sc = new Scanner(System.in);
        boolean encontro = false;

        if (validarCarpeta()) {
            abrirArchivoR();
            if (oi != null) {
                System.out.print("Indique parámetro de busqueda:");
                parametro = sc.nextLine();
                try {
                    p = (Persona) oi.readObject();
                    if (p.getNombre().toLowerCase().contains(parametro.toLowerCase()) || p.getApellidos().toLowerCase().contains(parametro.toLowerCase()) || p.getTelefono().toLowerCase().contains(parametro.toLowerCase())) {
                        System.out.println(p.toString());
                        encontro = true;
                    }
                } catch (EOFException e) {
                    p = null;
                    //e.printStackTrace();                        
                } catch (Exception e) {
                    p = null;
                    e.printStackTrace();
                }
                while (p != null) {
                    try {
                        p = (Persona) oi.readObject();
                        if (p.getNombre().toLowerCase().contains(parametro.toLowerCase()) || p.getApellidos().toLowerCase().contains(parametro.toLowerCase()) || p.getTelefono().toLowerCase().contains(parametro.toLowerCase())) {
                            System.out.println(p.toString());
                            encontro = true;
                        }

                    } catch (EOFException e) {
                        p = null;
                    } catch (Exception e) {
                        p = null;
                        e.printStackTrace();
                    }
                }
                //Cerramos el objeto inputstream y el objeto archivo
                try {
                    oi.close();
                    fi.close();
                } catch (Exception ex) {

                }

            }
        }
        if (!encontro) {
            System.out.println("No se encontraron registros");
        }
        System.out.println("Fin de la búsqueda.\n");
        return rta;
    }

    public static boolean reportePersonas() {
        System.out.println("====================");
        System.out.println("CONSULTA COMPLETA DE PERSONAS");
        System.out.println("====================");

        boolean rta = true;
        String parametro = null;
        Persona p = null;
        Scanner sc = new Scanner(System.in);
        boolean encontro = false;

        if (validarCarpeta()) {
            abrirArchivoR();
            do {
                try {
                    p = (Persona) oi.readObject();
                    System.out.println(p.toString());
                    encontro = true;
                } catch (EOFException e) {
                    p = null;
                } catch (Exception e) {
                    p = null;
                    //e.printStackTrace();
                }
            } while (p != null);
            
            //Cerramos el objeto inputstream y el objeto archivo
            try {
                oi.close();
                fi.close();
            } catch (Exception ex) {

            }

        }

        if (!encontro) {
            System.out.println("No se encontraron registros");
        }
        System.out.println("Fin del reporte.\n");
        return rta;
    }

    public static boolean eliminarPersona() {
        System.out.println("=================");
        System.out.println("ELIMINAR PERSONAS");
        System.out.println("=================");

        boolean rta = true;
        String parametro = null;
        Persona p = null;
        Scanner sc = new Scanner(System.in);
        boolean borrar = false;
        boolean encontro = false;
        String confirmacion = "N";

        ArrayList<Persona> personas = new ArrayList<Persona>();
        if (validarCarpeta()) {
            abrirArchivoR();
            if (oi != null) {
                System.out.println("Indique valor de busqueda:");
                parametro = sc.nextLine();
                try {
                    p = (Persona) oi.readObject();
                    if (p.getNombre().toLowerCase().contains(parametro.toLowerCase()) 
                            || p.getApellidos().toLowerCase().contains(parametro.toLowerCase()) 
                            || p.getTelefono().toLowerCase().contains(parametro.toLowerCase())) {
                        encontro = true;
                        System.out.println("Encontrado registro: " + p.toString());
                        System.out.print("Se va a eliminar el siguiente registro. Esta de acuerdo? S/N:");
                        confirmacion = sc.next();
                        if (confirmacion.toUpperCase().equals("N")) {
                            personas.add(p);
                        } else {
                            borrar = true;
                        }
                    } else {
                        personas.add(p);
                    }
                } catch (EOFException e) {
                    p = null;
                    e.printStackTrace();
                } catch (Exception e) {
                    p = null;
                    e.printStackTrace();
                }

                while (p != null) {
                    try {
                        p = (Persona) oi.readObject();
                        if (p.getNombre().toLowerCase().contains(parametro.toLowerCase().toLowerCase()) || p.getApellidos().toLowerCase().contains(parametro.toLowerCase()) || p.getTelefono().toLowerCase().contains(parametro.toLowerCase())) {
                            encontro = true;
                            System.out.println("Encontrado registro: " + p.toString());
                            System.out.print("Se va a eliminar el siguiente registro. Esta de acuerdo? S/N:");
                            confirmacion = sc.next();
                            if (confirmacion.toUpperCase().equals("N")) {
                                personas.add(p);
                            } else {
                                borrar = true;
                            }
                        } else {
                            personas.add(p);
                        }
                    } catch (EOFException e) {
                        p = null;
                    } catch (Exception e) {
                        p = null;
                        e.printStackTrace();
                    }
                }
                //Cerramos el objeto inputstream y el objeto archivo
                try {
                    oi.close();
                    fi.close();
                } catch (Exception ex) {

                }

            }
        }
        if (!encontro) {
            System.out.println("No se encontraron registros");
        }
        if (borrar) {
            reescribir(personas);
            System.out.println("Registro(s) eliminados!");
        }
        return rta;
    }

    private static void reescribir(ArrayList<Persona> personas) {
        boolean confirmacion = true;
        Path path = Paths.get("");
        String directoryName = path.toAbsolutePath().toString();
        File carpeta = new File(directoryName + File.separator + RUTA);
        File archivoDatos = new File(carpeta.getAbsolutePath() + File.separator + ARCHIVO);
        boolean archivoExiste = false;
        if (archivoDatos.exists()) {
            archivoDatos.delete();
        }
        Persona p = null;
        Iterator it = personas.iterator();
        while (it.hasNext()) {
            p = (Persona) it.next();
            add(p, confirmacion);
        }
    }

    public static boolean registrarPersona() {
        System.out.println("====================");
        System.out.println("REGISTRO DE PERSONAS");
        System.out.println("====================");

        boolean rta = true;
        boolean confirmacion = false;
        Persona p = new Persona();
        Scanner sc = new Scanner(System.in);
        System.out.print("Ingrese el nombre:");
        p.setNombre(sc.nextLine());
        System.out.print("Ingrese el apellido:");
        p.setApellidos(sc.nextLine());
        System.out.print("Ingrese el telefono:");
        p.setTelefono(sc.nextLine());
        rta = add(p, confirmacion);
        return rta;
    }

    public static boolean modificarPersona() {
        System.out.println("=================");
        System.out.println("MODIFICAR PERSONAS");
        System.out.println("=================");

        boolean rta = true;
        String parametro = null;
        Persona p = null;
        Scanner sc = new Scanner(System.in);
        boolean modificar = false;
        boolean encontro = false;
        String confirmacion = "N";

        ArrayList<Persona> personas = new ArrayList<Persona>();
        if (validarCarpeta()) {
            abrirArchivoR();
            if (oi != null) {
                System.out.println("Indique valor de busqueda:");
                parametro = sc.nextLine();
                do {
                    try {
                        p = (Persona) oi.readObject();
                        if (p.getNombre().toLowerCase().contains(parametro.toLowerCase())
                                || p.getApellidos().toLowerCase().contains(parametro.toLowerCase())
                                || p.getTelefono().toLowerCase().contains(parametro.toLowerCase())) {
                            encontro = true;
                            System.out.println("Encontrado registro: " + p.toString());
                            System.out.print("Se va a modificar informacion de el siguiente registro. Esta de acuerdo? S/N:");
                            confirmacion = sc.next();
                            if (confirmacion.toUpperCase().equals("N")) {
                                personas.add(p);
                            } else {
                                sc = new Scanner(System.in);
                                System.out.print("Ingrese el nuevo nombre:");
                                p.setNombre(sc.nextLine());
                                System.out.print("Ingrese el nuevo apellido:");
                                p.setApellidos(sc.nextLine());
                                System.out.print("Ingrese el nuevo telefono:");
                                p.setTelefono(sc.nextLine());
                                personas.add(p);
                                modificar = true;
                            }
                        } else {
                            personas.add(p);
                        }

                    } catch (EOFException e) {
                        p = null;
                        //e.printStackTrace();
                    } catch (Exception e) {
                        p = null;
                        //e.printStackTrace();
                    }
                } while (p != null);
                try {                    
                    oi.close();
                    fi.close();
                } catch (Exception ex) {

                }

            }
        }
        if (!encontro) {
            System.out.println("No se encontraron registros");
        }
        if (modificar) {
            reescribir(personas);
            System.out.println("Registro(s) modificados!");
        }
        return rta;
    }

}
