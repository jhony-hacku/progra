/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package archivos;

import java.io.IOException;
import java.util.Scanner;

/**
 *
 * @author user
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int opcion=0;
        do {
            try{
                opcion=mostrarMenu();
            }
            catch(Exception e){
                
            }
            
        }while (opcion!=6);
    }
    
    
    private static int mostrarMenu() throws IOException{
        int opcion;
        Scanner s = new Scanner (System.in);
        System.out.println("===============");
        System.out.println("Agenda personal");
        System.out.println("===============");
        System.out.println("1. Adicionar persona");
        System.out.println("2. Eliminar persona");
        System.out.println("3. Consultar persona");
        System.out.println("4. Reporte de persona");
        System.out.println("5. Modificar persona");
        System.out.println("6. Salir\n");        
        System.out.print("Seleccione Opción:");
        opcion = s.nextInt();
        procesarOpcion(opcion);
        return opcion;
    }
    
    private static void procesarOpcion(int opcion) throws IOException{
        switch(opcion){
            case 1: DML.registrarPersona();
                    System.out.println("Presione enter para continuar");
                    System.in.read();
                    break;
            case 2: DML.eliminarPersona();
                    System.out.println("Presione enter para continuar");                    
                    System.in.read();
                    break;
            case 3: DML.consultarPersona();
                    System.out.println("Presione enter para continuar");
                    System.in.read();
                    break;
            case 4: DML.reportePersonas();
                    System.out.println("Presione enter para continuar");
                    System.in.read();
                    break;                    
            case 5: DML.modificarPersona();
                    System.out.println("Presione enter para continuar");
                    System.in.read();
                    break;                    
        }
        
    }
}
