/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package barcos;

import barcos.*;

/**
 *
 * @author user
 */
public class Crucero {
    private float slora ;
    private int capacidad;
    private float  manga;
    private int motores;
    private float potencia;
    private float calado;
    private String marca;
    private String nombre;
    private int nroPasajeros;

    public int getNroPasajeros() {
        return nroPasajeros;
    }

    public void setNroPasajeros(int nroPasajeros) {
        this.nroPasajeros = nroPasajeros;
    }
    

    public float getSlora() {
        return slora;
    }

    public void setSlora(float slora) {
        this.slora = slora;
    }

    public int getCapacidad() {
        return capacidad;
    }

    public void setCapacidad(int capacidad) {
        this.capacidad = capacidad;
    }

    public float getManga() {
        return manga;
    }

    public void setManga(float manga) {
        this.manga = manga;
    }

    public int getMotores() {
        return motores;
    }

    public void setMotores(int motores) {
        this.motores = motores;
    }

    public float getPotencia() {
        return potencia;
    }

    public void setPotencia(float potencia) {
        this.potencia = potencia;
    }

    public float getCalado() {
        return calado;
    }

    public void setCalado(float calado) {
        this.calado = calado;
    }
    

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
 
    
}
