/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package interfaces.problema1;

/**
 *
 * @author user
 */
public interface Interfaz1 {
    public int y=0;
    public int metodo1(String x);
    //public String mostrar();
}
