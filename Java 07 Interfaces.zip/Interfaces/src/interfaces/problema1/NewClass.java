/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package interfaces.problema1;

/**
 *
 * @author user
 */
public class NewClass implements Interfaz1, Interfaz2{
      public boolean metodo1(int p1){
          
          return true;
      }
      public int metodo1(String x){
          return 1;
      }
      
      public int mostrar(){
            return 0;
      }
      
      /*public String mostrar(){
            return "Mostrar String";
      }*/
    

}
