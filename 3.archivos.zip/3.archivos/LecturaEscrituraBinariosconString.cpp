#include <iostream>
#include <fstream>
#include <string>


using namespace std;
struct Estudiante {
    string nombre;
    string codigo;
    float notas[3];
};

// Función para escribir una cadena en el archivo (con el tamaño primero)
void guardarString(ofstream& file, const string& str) {
    size_t size = str.size();
    file.write(reinterpret_cast<const char*>(&size), sizeof(size));
    file.write(str.c_str(), size);
}

// Función para leer una cadena desde el archivo (con el tamaño primero)
string leerString(ifstream& file) {
    size_t size;
    file.read(reinterpret_cast<char*>(&size), sizeof(size));
    string str(size, '\0');
    file.read(&str[0], size);
    return str;
}

int main() {
    Estudiante estudiante;
    estudiante.nombre = "Juan Perez";
    estudiante.codigo = "ABC123";
    estudiante.notas[0] = 8.5;
    estudiante.notas[1] = 7.2;
    estudiante.notas[2] = 9.0;

    // Escribir la estructura en el archivo binario
    ofstream outFile("estudiantes1.dat", ios::binary);
    if (outFile) {
        guardarString(outFile, estudiante.nombre);
        guardarString(outFile, estudiante.codigo);
        outFile.write(reinterpret_cast<const char*>(estudiante.notas), sizeof(estudiante.notas));
        outFile.close();
    } else {
        cout << "Error al abrir el archivo para escritura." << endl;
        return 1;
    }

    // Leer el archivo binario y recuperar la estructura
    Estudiante estudianteLeido;
    ifstream inFile("estudiantes1.dat", ios::binary);
    if (inFile) {
        estudianteLeido.nombre = leerString(inFile);
        estudianteLeido.codigo = leerString(inFile);
        inFile.read(reinterpret_cast<char*>(estudianteLeido.notas), sizeof(estudianteLeido.notas));
        inFile.close();
    } else {
        cout << "Error al abrir el archivo para lectura." << endl;
        return 1;
    }

    // Imprimir los datos leídos
    cout << "Nombre: " << estudianteLeido.nombre << endl;
    cout << "Codigo: " << estudianteLeido.codigo << endl;
    cout << "Notas: " << estudianteLeido.notas[0] << ", " << estudianteLeido.notas[1] << ", " << estudianteLeido.notas[2] << endl;

    return 0;
}
