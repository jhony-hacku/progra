-- No tienen sentido hacer un producto cartesiano simple
SELECT *
FROM INSTRUCTOR, department
WHERE INSTRUCTOR.DEPT_NAME = DEPARTMENT.DEPT_NAME;

-- Ejercicios b�sicos
SELECT ID
       , NAME
       , INST.DEPT_NAME
       , SALARY
       , BUILDING
       , BUDGET
FROM INSTRUCTOR INST, department dept
WHERE (INST.DEPT_NAME = dept.DEPT_NAME) and --(inst.salary > 90000 and inst.salary < 100000)
                                            (inst.salary between 90000 and 100000)
order by dept.building, inst.salary asc, inst.name;

-- Teoria de conjuntos
(SELECT 
         DEPT_NAME
        , ID
FROM INSTRUCTOR 
WHERE DEPT_NAME = 'Cybernetics')
UNION
(SELECT ID AS "ASDF ASD"
        , DEPT_NAME
FROM INSTRUCTOR 
WHERE DEPT_NAME = 'Elec. Eng.');



