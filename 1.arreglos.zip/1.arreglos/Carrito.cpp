		
 #include <stdio.h>  
 #include <iostream>
 #include <windows.h>  
 #include <conio.h>
 #include <cstdlib> 
 #include <ctime>
 
 #define cx1 5
 #define cx2 70
 #define cy1 5
 #define cy2 16
 #define RED_COLOR "\033[31m"
 #define RESET_COLOR "\033[0m"

 
 
 using namespace std;
 void armarPista();
 void moverCarro();
 void pintarCarro (int x, int y,int puntaje);
 void borrarCarro (int x, int y);
 char matrizPiedras[cy2-cy1-1][cx2-cx1-1];
 void rellenoPiedras(); 
 int aleatorio(int min,int max);
 int puntaje=0;
 int carroX=cx1+1;
 int carroY=((int) ((cy1+cy2)/2)-2 );
 
 void ocultarCursor(){
 	HANDLE consoleHandle = GetStdHandle(STD_OUTPUT_HANDLE);
    CONSOLE_CURSOR_INFO cursorInfo;

    // Obtenemos la información actual del cursor
    GetConsoleCursorInfo(consoleHandle, &cursorInfo);

    // Ocultamos el cursor
    cursorInfo.bVisible = false;
    SetConsoleCursorInfo(consoleHandle, &cursorInfo);
 
 
 }
  
 void AltEnter()
{
    keybd_event(VK_MENU,
                0x38,
                0,
                0);
    keybd_event(VK_RETURN,
                0x1c,
                0,
                0);
    keybd_event(VK_RETURN,
                0x1c,
                KEYEVENTF_KEYUP,
                0);
    keybd_event(VK_MENU,
                0x38,
                KEYEVENTF_KEYUP,
                0);
    return;
}
 
 
 void gotoxy(int x,int y){  
      HANDLE hcon;  
      hcon = GetStdHandle(STD_OUTPUT_HANDLE);  
      COORD dwPos;  
      dwPos.X = x;  
      dwPos.Y= y;  
      SetConsoleCursorPosition(hcon,dwPos);  
 }  
  
 
  

 int main(){
 	AltEnter();
 	Sleep(1000);
 	ocultarCursor();
 	armarPista();
 	rellenoPiedras();
 	pintarCarro (cx1+1,((int) ((cy1+cy2)/2)-2 ),puntaje);
 	moverCarro();
 	
 	return 0;
 }
 
 
 void moverCarro(){
 	int lastY=((int) ((cy1+cy2)/2)-2 );
 	char tecla=0; 	
	while (tecla!=27){
		//cout<<" aleatorio:"<<aleatorio(0,cy2-cy1-2);
		Sleep(10);
		rellenoPiedras();		
		if(kbhit()){
            tecla = getch();
            switch(tecla){
            	//Arriba
            	case 72: 
            			borrarCarro(carroX,lastY);
            			if (lastY<=(cy1+1))
            				carroY=cy1+1;
						else
							carroY=lastY-1;						
						lastY=carroY;
						break;
            	//abajo
				case 80:
						borrarCarro(carroX,lastY);
						if ( (lastY+1)>=(cy2-3) )
            				carroY=cy2-3;
						else
							carroY=lastY+1;						
						lastY=carroY;
				break;	            	
			}
    	}	
		pintarCarro(carroX,carroY, puntaje);		
	} 	
 	
 
 
 }
 
 
 
 void armarPista(){
    //Pintar lineas verticales
	for (int y=cy1;y<=cy2;y++){
		gotoxy(cx1,y);
		cout<<char(186);	
	}
	for (int y=cy1;y<=cy2;y++){
		gotoxy(cx2,y);
		cout<<char(186);	
	}
		
	
 	//Pintar lineas horizontales
	for (int x=cx1+1;x<=cx2-1;x++){
		gotoxy(x,cy1);
		cout<<char(205)	;	
	}
	
	for (int x=cx1+1;x<=cx2-1;x++){
		gotoxy(x,cy2);
		cout<<char(205)	;	
	}
/**/	
	//pintar esquinas
	gotoxy(cx1,cy1);
	cout <<char(201);
	gotoxy(cx1,cy2);
	cout <<char(200);
	gotoxy(cx2,cy1);
	cout <<char(187);
	gotoxy(cx2,cy2);
	cout <<char(188);

 }
 
 void pintarCarro (int x, int y, int puntaje){
 	char llanta=' ';
 	if (puntaje%2==0)
 		llanta=char(79);
 	else
 		llanta='0';
 		
 	
 	char carro[3][14]={  ' ',' ',' ',char(220),char(220),char(220),char(220),char(220),char(220),' ',' ',' ',' ',' ',
 	
						 char(220),char(220),char(219),char(219),char(218),char(191),char(219),char(218),char(191),char(219),char(220),char(220),char(220),char(220),
						 
						 char(223),char(223),llanta,char(223),char(223),char(223),char(223),char(223),char(223),char(223),char(223),llanta,char(223),char(223)
				 	};
   				 	
				 	
 	gotoxy(x,y);
 	for (int i=0;i<3;i++){
		for (int j=0;j<14;j++){
			gotoxy (x+j,y+i);
			HANDLE hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
			if ( (i==1 && j==13) || (i==2 && j==2) ||(i==2 && j==11)   ){
				SetConsoleTextAttribute(hConsole, FOREGROUND_RED| FOREGROUND_GREEN | FOREGROUND_BLUE | FOREGROUND_INTENSITY); // Cambia el color a rojo intenso
			}else if (i==1 && j==0) {
					SetConsoleTextAttribute(hConsole, FOREGROUND_RED | FOREGROUND_INTENSITY); // Cambia el color a rojo intenso
				}
				else{
					SetConsoleTextAttribute(hConsole, FOREGROUND_BLUE |FOREGROUND_GREEN | FOREGROUND_INTENSITY); // Cambia el color a rojo intenso
				}
			cout <<carro[i][j];		
		    SetConsoleTextAttribute(hConsole, FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE); // Restaurar el color predeterminado
		}
	}
 	
 }
  void borrarCarro (int x, int y){
  //	Sleep(200);
 	char carro[3][14]={  ' ',' ',' ',char(220),char(220),char(220),char(220),char(220),char(220),' ',' ',' ',' ',' ',
 	
						 char(220),char(220),char(219),char(219),char(218),char(191),char(219),char(218),char(191),char(219),char(220),char(220),char(220),char(220),
						 
						 char(223),char(223),char(79),char(223),char(223),char(223),char(223),char(223),char(223),char(223),char(223),char(79),char(223),char(223)
				 	};
   				 	
				 	
 	gotoxy(x,y);
 	for (int i=0;i<3;i++){
		for (int j=0;j<14;j++){
			gotoxy (x+j,y+i);
		//	Sleep(200);
			cout <<' ';		
		}
	}	
 //	getch(); 	
 }
 
 void rellenoPiedras(){
 	static bool primeraVezP = true;
 	static int iteracion=0;
 	int posYPiedra=0;
 	int filas=cy2-cy1-1;
 	int cols=cx2-cx1-1;
 	if (primeraVezP){
		primeraVezP=false;
	 	for (int i=0;i<filas;i++)
	 		for (int j=0;j<cols;j++)
	 			matrizPiedras[i][j]=' ';
	}
	//Debo pasar todo lo de una columna a su columna anterior
	for (int i=0;i<filas;i++)
	 	for (int j=1;j<cols;j++)
	 		matrizPiedras[i][j-1]=matrizPiedras[i][j];
	//Reiniciar ultima columna 		
	for (int i=0;i<filas;i++)
		matrizPiedras[i][cols-1]=' ';		
	//En la ultima columna colocar una piedra aleatoria, pero se debe dejar espacio al carro para pasar es decir largo del carro +2
	if (iteracion%20==0){
		posYPiedra=aleatorio(0,cy2-cy1-2);
		matrizPiedras[posYPiedra][cols-1]=char(219);	
		//matrizPiedras[posYPiedra][cols-1]='';	
	}
	iteracion++;
	gotoxy(cx1,cy1-2);
	cout<<"Jugador: Juan Gomez - Puntaje: "<<iteracion;	
	puntaje=iteracion;
	
	for (int j=0;j<cols;j++){
			int px=cx1+j+1 ;
	for (int i=0;i<filas;i++){
		int py=cy1+i+1;
 		
			 gotoxy (px,py); 
			 char piedra=matrizPiedras[i][j];
			 if ( !( px>=(carroX-1) &&  px<=carroX+13 && py>=(carroY) && py<=carroY+2) ){	
			        cout<<matrizPiedras[i][j];
			  }
			  else{
			  	if (matrizPiedras[i][j]==char(219) )  {				  
			  		gotoxy(cx1,cy2+5);
			 		cout<< "Perdiste";
			 		getch();
			 		exit(0);
			 	}
			  }
	 	} 	
	}
 }
 
 
 int aleatorio(int min, int max) {
    static bool primeraVez = true;
    if (primeraVez) {
        srand(time(0)); // Inicializar la semilla de rand() con el tiempo actual
        primeraVez = false;
    }
    int random_number = min + rand() % (max - min + 1);
    return random_number;
} 	


 