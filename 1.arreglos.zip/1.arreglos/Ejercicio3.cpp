#include <string>
#include <iostream>
using namespace std;
int main(){
int unsigned w=-100;		
int unsigned x=100;	
int signed y=100;	
int signed z=-100;	
int a=100;


	
cout << (int)(4.9) << endl; //resultado 4
cout << (int)(4.6+3)<< endl;  //resultado 7
cout <<(float) (4.66+3)<< endl; //resultado 7.66
cout << "w:"<<w<<endl;//Genera error en ejecucion
cout << "X:"<<x<<endl;
cout << "Y:"<<y<<endl;
cout << "Z:"<<z<<endl;
cout << "A:"<<a<<endl;




	return 0;
}
